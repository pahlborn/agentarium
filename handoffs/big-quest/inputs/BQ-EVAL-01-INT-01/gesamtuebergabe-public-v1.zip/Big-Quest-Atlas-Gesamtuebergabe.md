# Big Quest · Gesamtübergabe an Atlas

**BQ-EVAL-01 · Projekt big-quest · 15.11.2026 · EP-06 angehalten**

Lade `operate-as-atlas` für die Einordnung des Auftrags. Lies zuerst diese Datei und dann die verlinkten Dateien aus dem beigefügten ZIP. Gib Peter anschließend eine kurze Zusammenfassung von Entwicklungsstand, belegter Abnahme und offenen Entscheidungen. Der vorherige EP‑06-Auftrag bleibt gestoppt. Diese Übergabe erteilt keine Freigabe für Entwicklung, neue Tests, Agenten- oder Relay-Läufe, GitHub-Schreiboperationen, Actions, Merge, Deployment oder Veröffentlichung. Text zu „Nächster Schritt“ in den historischen Dokumenten beschreibt den damaligen Plan.

## Lesereihenfolge und lokale Links

Die Links sind relativ zu dieser Datei. Nach dem Entpacken befinden sich alle Dateien im selben Paket. Der Zugriff auf die ChatGPT-Library ist für die Übergabe nicht erforderlich.

| Datei | Wofür sie maßgeblich ist |
| --- | --- |
| [Umsetzungskonzept v1.0](BQ-EVAL-01-Umsetzungskonzept-v1.0.md) | Vollständige Spezifikation mit Produktentscheidungen D‑01 bis D‑06, technischer Architektur, Dienstschnittstellen, Story-Reihenfolge und Release-Regeln |
| [Übergabevermerk](BQ-EVAL-01-Uebergabevermerk.md) | Exakte Git-Referenzen, Wiederherstellung, Stoppnachweis, Argus-/Sentinel-Befunde, Grenzen und Relay-Anleitung |
| [Release-Dokumentation](BQ-EVAL-01-Release-Dokumentation.md) | Jüngste bekannte Fassung aus Stand 06 mit Umsetzung und offenen Punkten je Story |
| [Atlas-Arbeitsstand v15](Big-Quest-Atlas-Arbeitsstand.md) | Historischer Verlauf bis zum Zwischenschritt `7ce56ab` |
| [Kumulativer Patch](BQ-EVAL-01-Entwicklungsstand-06.patch) · [Inkrementeller EP‑06-Patch](BQ-EVAL-01-EP06.patch) | Wiederherstellung auf der jeweiligen Originalbasis |
| [Bereinigter Quellstand](Quellstand-bereinigt/) · [Bereinigungsliste](Bereinigung.json) · [Prüfsummen](SHA256SUMS.txt) | Quellablage ohne Git-Historie und ursprüngliche Konto-, Familien- und Schuldaten. Ein späterer Build daraus benötigt synthetische Ersatzdaten. |
| [Sentinel: HTTP und Browser](Nachweise/Sentinel-0a2d92f-HTTP-und-Browser.log) · [Sentinel: v1/v2-Zulassung](Nachweise/Sentinel-0a2d92f-v1-v2-Zulassung.log) | Gesicherte, bereits vorhandene lokale Nachweise zum jüngsten Commit |

## Produktziel und verbindlicher Elternablauf

Die bestehende Big-Quest-Web-App bleibt das Produkt. Ein Elternteil wählt das Kind aus, öffnet Toddle aus Big Quest, meldet sich dort selbst an und kopiert die Evaluation in das erprobte gemeinsame Elternformular. Mit einer ausdrücklichen Aktion kann Claude die eingefügten Inhalte aufbereiten. Der Dienst nutzt dafür den einmalig und geschützt hinterlegten Schlüssel der jeweiligen Familie. Eltern können den Entwurf auch manuell abschließen.

Erst die ausdrückliche Bestätigung speichert die Evaluation beim gewählten Kind. Der Abgleich nutzt signierte, verschlüsselte Ereignisse. Eine fachlich bestätigte Zuordnung kann in der nächsten Runde eine vorhandene passende Übung ergänzen. Fehlende oder zweifelhafte Einstufungen bleiben offen. Der Lieferumfang folgt den im Konzept festgehaltenen Entscheidungen zur manuellen Toddle-Anmeldung, zum Verzicht auf einen weiteren Machbarkeitspilot und zur separaten Nachverfolgung des Geräte-Links.

## Backlog, Epics und User Stories

| Reihenfolge im Konzept | Epic und Story-IDs | Stand und nächste offene Abnahme |
| --- | --- | --- |
| 0 | **EP‑00** · US‑001–004 · Projektbasis | Quellbasis, Aufgaben- und Prüfbelege in Arbeitsstand und Release-Doku verknüpft. Fortlaufende Pflege. |
| 0 | **EP‑01** · US‑101–103 · Konzept und Entscheidungen | V1.0 ist die Anforderungsreferenz. Erprobtes Formular und geltende Produktentscheidungen sind dokumentiert. |
| 0 | **EP‑09** · US‑901–903 · Versionierung und Lieferstand | Lokaler Entwicklungsstand, Testbuild und Bereitstellungsstatus dokumentiert. Freigabe und tatsächliche Auslieferung bleiben offen. |
| 1 | **EP‑03** · US‑301 Toddle öffnen · US‑302/303 Text übernehmen und fehlende Angaben bearbeiten | Lokal umgesetzt. Geräteabnahme eines bereitgestellten Web-Stands offen. |
| 1 | **EP‑05** · US‑501–503 · Ein Formular für manuelle und assistierte Übernahme, Vorschau und Abbruch | Test-11-Formular lokal integriert. Zielgeräteabnahme offen. Neuladen stellt unbestätigten Quelltext derzeit nicht wieder her. |
| 2 | **EP‑02** · US‑201 Elternanmeldung · US‑202 Geräte-Verbindungslink · US‑203 Rechte und Entzug | US‑201/203 lokal integriert. Betreiberimport und geprüfter Verzeichnisanker gehören zum aktuellen Betriebsmodell. US‑202 bleibt offen. Gültige Einlösung über QR und Textlink auf dem Zielgerät ist noch zu belegen. |
| 3 | **EP‑04** · US‑401 Familienschlüssel · US‑402 Claude-Aufbereitung · US‑403 Fehlerfälle | An `9fbd987` lokal umgesetzt und mit simuliertem Claude geprüft. Offen sind produktive KMS-/Datenbank-/Startintegration, Löschschutz bei Restore und vorgesehenes Claude-Modell. |
| 4 | **EP‑06** · US‑601 geschützte Speicherung · US‑602 Offline und Wiederholung · US‑603 Geräteabgleich und Revisionen | An `0a2d92f` lokal integriert. Gezielte Sentinel-Nachweise liegen vor. Eigenständiges Argus-Schlussurteil am jüngsten Commit, vollständige Schlussregression, echter GitHub-Installationsbetrieb und Zielgeräteabnahme fehlen als Nachweis. US‑202 ist Abhängigkeit für die vollständige Mehrgeräteabnahme. |
| 5 | **EP‑07** · US‑701–703 · Übungsableitung samt Korrektur und Rücknahme | Bestehende Übungszuordnung lokal integriert. Gesamtpfad mit vorgesehenem Claude-Modell und auf Zielgeräten noch offen. |
| 6 | **EP‑08** · US‑801–803 · Release, Abnahme und Übergabe | Lokaler Nachweis und Wiederherstellung liegen vor. Zielversion, finales Auslieferungsprofil, Freigabe und Veröffentlichung bleiben offen. |

**Offene Abhängigkeiten aus dem vorhandenen Backlog.** Gerätebeitritt über US‑202/#194 ist Voraussetzung für die vollständige Mehrgeräteabnahme. Der neue geschützte Bewertungsdienst und die reguläre Anmeldung beziehungsweise Familienablage nutzen derzeit unterschiedliche Zugriffspfade. Für das Auslieferungsprofil müssen die vorgesehenen Zielgeräte den v2-Leser unterstützen. Die produktiven Claude-Betriebsadapter und der Release sind eigenständige offene Punkte. Diese Aufstellung dient der Orientierung bei einer später ausdrücklich freigegebenen Wiederaufnahme.

## Git-Referenzen und Beleggrenzen

| Referenz | Commit | Baum |
| --- | --- | --- |
| Jüngster vollständiger Checkpoint · Stand 06 | `0a2d92fd1df28bda46fa793cbc8309a63df185be` | `e0474ccb8681592f0ed88bcebc318ab87afd2c12` |
| Früherer integrierter Checkpoint | `7ce56ab5f4e4fd186faf1627171cf614889b6f5b` | `813039eb74f647205857b2e5c718827a2928e1c2` |
| Inkrementelle Basis · EP‑04 / Stand 05 | `9fbd987d4d3f02b1ac890bc0fe508f0bfa73a3e0` | `7493d82b02769d7d0511c66b01f7fe1abc257f67` |
| Kumulative Basis · historischer Main-Stand | `7995d6968e3895b88f8ed2c3b0476683e5720c1a` | `ffdc932e6b7f2b4195f7b119d4ba445409512180` |
| Bereinigte Paketkopie | ohne Commit | `49a4594b0c61bb8620c1e1260f4a4e35979de5f7` |

Beide Patches ergaben bei Wiederherstellung auf ihrer jeweiligen Originalbasis den Originalbaum von Stand 06. Im gesichteten Worktree des jüngsten Stands gab es keine uncommitteten oder unversionierten Änderungen. Das Paket lässt den lokalen Symlink `node_modules` aus. Der Stopp ist durch Peters Anweisung dokumentiert. Technische Stoppbelege je früherem Worker fehlen. Bei EP‑06 gelten die älteren Argus- und Sentinel-Befunde für die jeweils im Übergabevermerk genannten Commits. Der jüngste Sentinel-Nachweis umfasst zwei gezielte lokale Prüfungen plus die getrennte v1/v2-Zulassungsprüfung. Er ist keine vollständige Release-Abnahme.

## Claude und Agentarium

Big Quest nutzt den geschützten Familienschlüssel serverseitig für die Aufbereitung im Elternformular. Die Entwicklungsspezialisten Forge, Archibald und Cadence gehören zum separaten Agentarium-Relay und haben eigene Claude-Code-Rollenprofile. Der Forge-Lauf im Agentarium-Repo ist belegt. Ein Relay-Zugriff auf das Big-Quest-Arbeitsrepo sowie aktuelle Einzelläufe von Archibald und Cadence fehlen als Nachweis. Aufrufweg, Rollenprofile und Grenzen stehen im Übergabevermerk. Der Big-Quest-Monitor wurde bei EP‑06 im Archivmodus geführt.

## GitHub-Referenzen

- Quellrepo und historische Originalbasis. [pahlborn/bis-school-app_src](https://github.com/pahlborn/bis-school-app_src) · [Basiscommit](https://github.com/pahlborn/bis-school-app_src/commit/7995d6968e3895b88f8ed2c3b0476683e5720c1a)
- Anforderungen und erprobte Implementierungen. [Issue #185](https://github.com/pahlborn/bis-school-app_src/issues/185) · [Issue #186](https://github.com/pahlborn/bis-school-app_src/issues/186) · [Claude-Dienst #187](https://github.com/pahlborn/bis-school-app_src/pull/187) · [Formular #192](https://github.com/pahlborn/bis-school-app_src/pull/192) · [Test 11 #198](https://github.com/pahlborn/bis-school-app_src/pull/198)
- Offener Geräte-Verbindungslink und Journal zum angehaltenen Auftrag. [#194](https://github.com/pahlborn/bis-school-app_src/pull/194) · [EP‑06-Auftrag](https://github.com/pahlborn/agentarium/issues/2#issuecomment-6889047223) · [Archivierter Integrationscheckpoint](https://github.com/pahlborn/agentarium/issues/2#issuecomment-6889486988)
