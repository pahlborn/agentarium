export const EVALUATION_BODY_LIMIT = 950_000;
const evaluationPath = /^\/v1\/children\/(p_[A-Za-z0-9]{1,40})\/(evaluations|evaluation-keys|evaluation-list|evaluation-bundle)$/;
const uuid = /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/;
const marker = /^[a-f0-9]{64}$/;
const eventId = /^e_[a-f0-9]{24}$/;
const deviceId = /^d_[0-9A-Za-z]{1,40}$/;
const bundleId = /^d_[0-9A-Za-z]{1,40}\/[1-9][0-9]{0,8}$/;
const base64 = /^[A-Za-z0-9+/]+={0,2}$/;
const obj = value => value && typeof value === 'object' && !Array.isArray(value);
const exact = (value, ...fields) => obj(value) && Object.keys(value).length === fields.length &&
  fields.every(field => Object.hasOwn(value, field));

export function schoolEvaluationRoute(path) {
  const match = evaluationPath.exec(path);
  return match && { child: match[1], action: match[2] };
}

function validEvaluation(value, grant) {
  if (!exact(value, 'operation', 'identity', 'bundle') || typeof value.operation !== 'string' || !uuid.test(value.operation) ||
    !(value.identity === null || (typeof value.identity === 'string' && marker.test(value.identity)))) return false;
  const { bundle } = value;
  if (!exact(bundle, 'v', 'kv', 'account', 'device', 'eintraege') || bundle.v !== 2 ||
    bundle.account !== grant.account || bundle.device !== grant.device ||
    !Number.isInteger(bundle.kv) || bundle.kv < 1 || bundle.kv > 999_999_999 ||
    !Array.isArray(bundle.eintraege) || bundle.eintraege.length !== 1) return false;
  const [entry] = bundle.eintraege;
  return exact(entry, 'id', 'iv', 'ct') && typeof entry.id === 'string' && eventId.test(entry.id) &&
    typeof entry.iv === 'string' && entry.iv.length === 16 && base64.test(entry.iv) &&
    typeof entry.ct === 'string' && entry.ct.length >= 24 && entry.ct.length % 4 === 0 && base64.test(entry.ct);
}

function validCursor(value, area) {
  return value === null || (exact(value, 'bereich', 'stand') && value.bereich === area && obj(value.stand) &&
    Object.entries(value.stand).every(([device, number]) => deviceId.test(device) &&
      Number.isInteger(number) && number >= 0 && number <= 999_999_999));
}

export function createEvaluationRoutes({ save, read }) {
  if (typeof save !== 'function' || !['keys', 'list', 'get'].every(key => typeof read?.[key] === 'function')) {
    throw new TypeError('Protected evaluation storage required');
  }
  return async function runEvaluation({ route, request, body, sessions, origin, send }) {
    const { headers, method, url: path } = request;
    const { child, action } = route;
    const write = action === 'evaluations';
    const token = /^Bearer ([A-Za-z0-9_-]{43})$/.exec(headers.authorization ?? '')?.[1];
    const at = /^\d{1,15}$/.test(headers['x-bq-at'] ?? '') ? Number(headers['x-bq-at']) : NaN;
    const grant = await sessions.authorize({
      origin, token, method, path, body, at, child, nonce: headers['x-bq-nonce'],
      signature: headers['x-bq-signature'], accountSignature: headers['x-bq-account-signature'],
      recheck: true, accountProofRequired: write, maxBody: write ? EVALUATION_BODY_LIMIT : 48_000,
    });
    const denied = () => send(403, { error: 'ACCESS_DENIED' });
    const invalid = () => send(400, { error: 'INVALID_INPUT' });
    if (!grant || !deviceId.test(grant.device)) return denied();
    let input;
    try { input = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(body)); }
    catch { return invalid(); }

    const area = 'schule:' + grant.child;
    let data;
    if (write) {
      if (!validEvaluation(input, grant)) return invalid();
      data = await save(grant, input);
      if (data.error === 'ACCESS_DENIED') return denied();
      if (data.error) return await grant.current() ? send(409, { error: data.error }) : denied();
    } else if (action === 'evaluation-keys') {
      if (!exact(input)) return invalid();
      const keys = await read.keys(area);
      data = Object.hasOwn(keys, grant.account) ? { [grant.account]: keys[grant.account] } : {};
    } else if (action === 'evaluation-list') {
      if (!exact(input, 'cursor') || !validCursor(input.cursor, area)) return invalid();
      data = await read.list(area, input.cursor);
    } else {
      if (!exact(input, 'id') || typeof input.id !== 'string' || !bundleId.test(input.id)) return invalid();
      data = await read.get(area, input.id);
    }
    return await grant.current() ? send(200, data) : denied();
  };
}
