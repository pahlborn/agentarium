// Existing parent sign-in against a local data store, with a separate service origin.
import { createServer } from 'node:http';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createSchoolAccountAuthority } from './account-authority.mjs';
import { openSchoolAccessStore } from './access-store.mjs';
import { createSchoolSessionServer } from './server.mjs';
import { githubEvaluationStore } from './evaluation-store.mjs';
import { createLocalClaudeKeyWrapper } from './claude-vault.mjs';
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { appServer, browserStarten, elternSeite } from '../../tests/app-hilfen.mjs';
import { githubNachbau } from '../../tests/module/github-nachbau.mjs';
import { githubSpeicher } from '../../src/module/github.mjs';
import { startcodeAusstellen, ersteAnmeldung, kontoLookup } from '../../src/module/konto.mjs';
import { anmEinladungslink } from '../../src/module/anmeldung.mjs';
import { keyFingerprint } from '../../src/module/krypto.mjs';

const REPO = 'pahlborn/bis-school-app-testdaten';
const TOKEN = 'github_pat_TESTTOKEN_' + 'E5mn'.repeat(10);
const SERVICE_TOKEN = 'github_pat_TESTTOKEN_' + 'E7sn'.repeat(10);
const CHILD = 'Tessa Sonnenweg';
const LOGIN = 'tessa.sonnenweg';

async function register(page) {
  await page.locator('#kontoNeuUse').click();
  await page.locator('#kontoNeuGo').click();
}

async function device(browser, allowed) {
  const context = await browser.newContext({ timezoneId: 'UTC' });
  await context.route('**/*', (route) => allowed.some((url) => route.request().url().startsWith(url)) ? route.continue() : route.abort());
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  return { page, errors };
}

test('existing parent registers once, configures Claude and confirms an assisted evaluation', { timeout: 180_000 }, async t => {
  const directory = await mkdtemp(join(tmpdir(), 'bq-access-'));
  t.after(() => rm(directory, { force: true, recursive: true }));
  const storage = await githubNachbau({ token: TOKEN, repos: [REPO], gitDataToken: SERVICE_TOKEN });
  t.after(() => storage.schliessen());
  const access = githubSpeicher({ repo: REPO, token: TOKEN, basis: storage.basis }).geraet('d_Werkzeug1');
  const adminCode = await startcodeAusstellen({ zugang: access, aussteller: null, anmeldename: 'admin', art: 'admin', now: Date.now() });
  const admin = await ersteAnmeldung({ zugang: access, code: adminCode.code, passwort: 'Werkzeug-Admin-Passwort-1', now: Date.now() });
  const parentCode = await startcodeAusstellen({ zugang: access, aussteller: admin, anmeldename: 'mira.sonnenweg', art: 'parent', now: Date.now() });
  const config = JSON.stringify({ art: 'github', repo: REPO, wurzel: '', basis: storage.basis });
  const dbPath = join(directory, 'access.sqlite');
  let rights = openSchoolAccessStore(dbPath);
  t.after(() => rights.close());
  const relay = createServer();
  await new Promise(resolve => relay.listen(0, '127.0.0.1', resolve));
  t.after(() => relay.close());
  const audience = 'http://127.0.0.1:' + relay.address().port;
  const server = await appServer({ bauart: 'test', anpassen: h => h.replace('/*BQ_SPEICHER*/null', () => config)
    .replace('/*BQ_SCHULDIENST*/null', JSON.stringify(audience))
    .replace('function kontoGeraeteHTML(){', 'window.serviceIdentity = () => ({ account: kontoIch().kennung, accountKey: kontoIch().pub.ecdsa, keyVersion: kontoIch().stand ?? 1, device: kontoGeraet(), child: schoolKid(), family: kontoVerb(kontoIch()).familie, anchor: kontoIch().ursprung });\nwindow.rotateServiceAccount = async password => { const k=kontoIch(); const neu={...k,...await anmErneuern({zugang:kontoZugang(), anmeldename:k.anmeldename, passwort:password, neuesPasswort:"Elephant-Cloud-927!"})}; await kontoMerken(neu); schuldienstVormerken(neu,"d_removed",[],true); await kontoAbgleich(); };\nfunction kontoGeraeteHTML(){') });
  const origin = new URL(server.url).origin;
  const keyWrapper = createLocalClaudeKeyWrapper(Buffer.alloc(32, 7));
  const fakeKey = 'sk-ant-test-' + 'abc'.repeat(12);
  const nextKey = 'sk-ant-test-' + 'xyz'.repeat(12);
  const source = ['Zweischrittige Stickeraufgabe', 'Assessment Criteria', 'Rechenweg erklären',
    'Teacher rating: C', 'OREO-Schema anwenden', 'Your response', 'OREO: E = Example'].join('\n');
  const calls = [];
  let providerStatus = 200;
  let releaseProvider;
  const request = async (_url, options) => {
    calls.push(new Headers(options.headers).get('x-api-key'));
    if (releaseProvider) await releaseProvider.promise;
    if (providerStatus !== 200) return new Response('{}', { status: providerStatus });
    const result = {
      title: 'Zweischrittige Stickeraufgabe', day: '2026-11-13', area: 'Mathematik',
      goal: 'Rechenweg begründen', instructions: '', feedback: '',
      criteria: [
        { criterion: 'Rechenweg erklären', criterionLine: 3, teacherLine: 4 },
        { criterion: 'OREO-Schema anwenden', criterionLine: 5, teacherLine: 7 },
      ],
    };
    return Response.json({ stop_reason: 'end_turn', content: [{ type: 'text', text: JSON.stringify(result) }] });
  };
  const serviceStorage = { repo: REPO, token: SERVICE_TOKEN, basis: storage.basis };
  const evaluations = { save: githubEvaluationStore(serviceStorage), read: githubSpeicher(serviceStorage).geraet('d_Schuldienst') };
  const startService = () => {
    const directoryAuthority = createSchoolAccountAuthority({ ...rights, directory: access.directory });
    const sessionServer = createSchoolSessionServer({ origin, audience, ...rights, directoryAuthority, testLoopback: true, evaluations,
      claude: { store: rights.claudeStore, keyWrapper, model: 'test-claude', request } });
    relay.removeAllListeners('request');
    relay.on('request', sessionServer.listeners('request')[0]);
  };
  startService();
  t.after(() => server.close());
  const browser = await browserStarten();
  t.after(() => browser.close());
  const allowed = [server.url, storage.basis, audience + '/'];
  const P = await device(browser, allowed);
  const K = await device(browser, allowed);

  await P.page.goto(anmEinladungslink(server.url, { zugang: TOKEN, anmeldename: 'mira.sonnenweg', code: parentCode.code, fingerabdruck: parentCode.fingerabdruck }));
  await P.page.locator('#kontoNeuUse').click();
  const password = await P.page.locator('#kontoNeuPw').inputValue();
  await P.page.locator('#kontoNeuGo').click();
  await P.page.locator('#recGo').click();
  await P.page.locator('#welcomeGo').click();
  await P.page.locator('#parentClose').waitFor();
  await P.page.locator('#pSettings').click();
  await P.page.locator('details.psec[data-psec="family"] > summary').click();
  await P.page.locator('#kKindAnlegen').click();
  await P.page.locator('#kKindName').fill(CHILD);
  await P.page.locator('#kKindWeiter').click();
  await P.page.locator('#kKindLogin').fill(LOGIN);
  await P.page.locator('#kKindGo').click();
  await P.page.locator('#kQr svg').waitFor();
  const code = (await P.page.locator('#kCode').textContent()).trim();
  const pub = await P.page.evaluate(async () => {
    const entries = await new Promise((resolve, reject) => {
      const db = indexedDB.open('bq2_konto', 1);
      db.onerror = () => reject(db.error);
      db.onsuccess = () => {
        const request = db.result.transaction('schluessel').objectStore('schluessel').getAll();
        request.onerror = () => reject(request.error);
        request.onsuccess = () => { db.result.close(); resolve(request.result); };
      };
    });
    assertSingleKey(entries);
    return entries[0].pub;
    function assertSingleKey(keys) {
      if (keys.length !== 1) throw new Error('Expected one key on the parent-only device');
    }
  });
  await K.page.goto(anmEinladungslink(server.url, { zugang: TOKEN, anmeldename: LOGIN, code, fingerabdruck: await keyFingerprint(pub) }));
  await register(K.page);
  await K.page.waitForSelector('#home:not([hidden])', { timeout: 60000 });
  await P.page.waitForFunction(() => /ist angemeldet/.test(document.querySelector('#kQrStatus')?.textContent || ''), null, { timeout: 30000 });
  await P.page.locator('#kQrFertig').click();

  const identity = await P.page.evaluate(() => window.serviceIdentity());
  const snapshot = { ...identity, family: identity.family, sequence: 1,
    validUntil: Date.now() + 600_000, children: [identity.child], devices: [identity.device, 'd_removed'],
    directoryAnchor: { lookup: await kontoLookup('mira.sonnenweg'), pub: identity.anchor } };
  rights.replaceAccount(snapshot);
  const oneTimeCode = rights.issueCode(identity.account, identity.device);
  async function check(code, accepted, alreadyOpen = false, { page } = P) {
    if (!alreadyOpen) {
      if (!(await page.locator('#pSetBack').count())) await page.locator('#pSettings').click();
      await page.locator('details.psec[data-psec="devices"] > summary').click();
    }
    const form = page.locator('#schuldienstForm');
    await form.locator('input').fill(code);
    await form.locator('button').click();
    await form.getByRole('status').getByText(accepted ? 'Dienstzugang für dieses Kind bestätigt.' : 'Dienstzugang konnte nicht bestätigt werden.').waitFor();
  }
  await check(oneTimeCode, true);
  const bound = rights.lookupDevice(identity.account, identity.device);
  assert.ok(bound.deviceKey);
  assert.equal(bound.enrollment, undefined);
  assert.throws(() => rights.issueCode(identity.account, identity.device));
  rights.close();
  rights = openSchoolAccessStore(dbPath);
  startService();
  await check('', true, true);
  const reported = P.page.waitForResponse(response => response.url() === audience + '/v1/session/rights');
  await P.page.evaluate(password => window.rotateServiceAccount(password), password);
  assert.equal((await reported).status(), 204);
  const current = rights.lookupDevice(identity.account, identity.device);
  assert.equal(current.keyVersion, 2);
  assert.equal(rights.lookupDevice(identity.account, 'd_removed').active, false);
  await check('', true, true);

  const P2 = await device(browser, allowed);
  await P2.page.goto(anmEinladungslink(server.url, { zugang: TOKEN }));
  await P2.page.locator('#roleAdult').click();
  await P2.page.locator('#loginUser').fill('mira.sonnenweg');
  await P2.page.locator('#loginPw').fill('Elephant-Cloud-927!');
  await P2.page.locator('#loginGo').click();
  await P2.page.locator('#parentClose').waitFor();
  await P2.page.waitForFunction(child => window.serviceIdentity().child === child, identity.child);
  const second = await P2.page.evaluate(() => window.serviceIdentity());
  assert.equal(second.account, identity.account);
  assert.notEqual(second.device, identity.device);
  const updated = { ...snapshot, keyVersion: current.keyVersion, accountKey: current.accountKey };
  rights.replaceAccount({ ...updated, sequence: 2, devices: [identity.device, second.device] });
  await check(rights.issueCode(identity.account, second.device), true, false, P2);
  await P2.page.locator('#pSetBack').click();
  await elternSeite(P2.page, 'school');
  await P2.page.evaluate(() => localStorage.removeItem('bqt_gh'));
  await P2.page.route(storage.basis + '/**', route => route.abort());
  assert.equal(await P2.page.evaluate(() => localStorage.getItem('bqt_gh')), null);
  // Opening the settings route also keeps the section selected if account sync rerenders it.
  await P.page.evaluate(() => { location.hash = '#eltern/einstellungen/claude'; });
  const settings = P.page.locator('#schoolClaudeSettings');
  await settings.getByText('Kein Schlüssel hinterlegt.', { exact: true }).waitFor();
  const saveKey = async value => {
    await settings.locator('#schoolClaudeApiKey').fill(value);
    await settings.getByRole('button', { name: 'Schlüssel speichern oder ersetzen' }).click();
    await settings.getByText('Schlüssel hinterlegt.', { exact: true }).waitFor();
    assert.equal(await settings.locator('#schoolClaudeApiKey').inputValue(), '');
  };
  await saveKey(fakeKey);
  await saveKey(nextKey);
  await P.page.locator('#pSetBack').click();
  await elternSeite(P.page, 'school');
  const form = P.page.locator('#pSchoolEvaluation');
  await form.getByRole('button', { name: 'Evaluation hinzufügen' }).click();
  await form.getByText('Aus Toddle übernehmen', { exact: true }).click();
  const copied = form.getByLabel('Kopierter Bewertungstext');
  await copied.fill(source);
  const prepare = form.getByRole('button', { name: 'Mit Claude aufbereiten' });
  const events = ({ page } = P) => page.evaluate(() => Array.from({length: localStorage.length}, (_, i) => localStorage.key(i))
    .filter(k => /__events$/.test(k)).flatMap(k => JSON.parse(localStorage.getItem(k)))
    .filter(e => e.type === 'school_evaluation'));
  providerStatus = 401;
  await prepare.click();
  await form.getByText(/Claude hat den Schlüssel abgelehnt/).waitFor();
  assert.equal(await copied.inputValue(), source);
  assert.deepEqual(await events(), []);
  providerStatus = 429;
  await prepare.click();
  await form.getByText(/Das Aufbereitungslimit ist erreicht/).waitFor();
  assert.equal(await copied.inputValue(), source);
  providerStatus = 200;
  releaseProvider = Promise.withResolvers();
  await prepare.click();
  await form.getByText(/bereitet den Text auf/).waitFor();
  const goal = form.locator('[name="doc-goal"]');
  await goal.fill('Manuell bearbeitet');
  releaseProvider.resolve();
  releaseProvider = null;
  await form.getByText(/Ihre Änderungen bleiben erhalten/).waitFor();
  assert.equal(await goal.inputValue(), 'Manuell bearbeitet');
  await prepare.click();
  await form.getByText(/Entwurf ergänzt/).waitFor();
  assert.equal(await goal.inputValue(), 'Manuell bearbeitet');
  assert.deepEqual(calls, Array(4).fill(nextKey));
  assert.equal(await form.getByLabel('Einstufung 1', { exact: true }).inputValue(), 'C');
  assert.equal(await form.getByLabel('Einstufung 2', { exact: true }).inputValue(), '');
  assert.deepEqual(await events(), []);
  await form.getByRole('button', { name: 'Vorschau anzeigen' }).click();
  await form.getByRole('heading', { name: 'Vorschau' }).waitFor();
  assert.deepEqual(await events(), []);
  const lost = Promise.withResolvers();
  const requests = [];
  await P.page.route(audience + '/v1/children/' + identity.child + '/evaluations', async route => {
    if (route.request().method() !== 'POST') return route.continue();
    requests.push(route.request().postDataJSON());
    if (requests.length !== 1) return route.continue();
    const committed = await route.fetch();
    lost.resolve(committed.status());
    await route.abort();
  });
  await P.page.context().setOffline(true);
  await form.getByRole('button', { name: 'Evaluation bestätigen' }).click();
  await form.getByText(/Lokal vorgemerkt/).waitFor();
  assert.deepEqual(await events(), [], 'offline confirmation is queued without projecting a committed assessment');
  const queued = () => P.page.evaluate(() => Array.from({ length: localStorage.length }, (_, i) => localStorage.key(i))
    .filter(k => k.includes('__schoolOutbox:')).map(k => localStorage.getItem(k)));
  const offline = await queued();
  assert.equal(offline.length, 1);
  const { iv, ct } = JSON.parse(offline[0]);
  assert.ok(iv && ct);
  assert.deepEqual(Object.keys(JSON.parse(offline[0])).sort(), ['ct', 'iv']);
  assert.ok(!offline[0].includes('Rechenweg erklären'));
  const waitForCommit = P.page.waitForRequest(request => request.url().endsWith('/evaluations') &&
    request.method() === 'POST', { timeout: 15_000 });
  await P.page.context().setOffline(false);
  await waitForCommit;
  assert.equal(await lost.promise, 200, 'service stored the assessment before the browser lost its response');
  await form.getByText(/Lokal vorgemerkt/).waitFor();
  await P.page.context().setOffline(true);
  await P.page.context().setOffline(false);
  await form.getByText('Serverseitig bestätigt.', { exact: true }).waitFor();
  assert.deepEqual(requests[1], requests[0], 'reconnect retries exactly the same signed intent body');
  assert.deepEqual(await queued(), []);
  await P2.page.evaluate(() => window.dispatchEvent(new Event('online')));
  await P2.page.getByText('Zweischrittige Stickeraufgabe', { exact: true }).waitFor();
  assert.equal(await P2.page.getByText('Zweischrittige Stickeraufgabe', { exact: true }).count(), 1);
  const saved = await events();
  assert.deepEqual(await events(P2), saved);
  assert.deepEqual(P2.errors, []);
  assert.equal(saved.length, 1);
  assert.equal(saved[0].payload.child, identity.child);
  assert.deepEqual(saved[0].payload.assessment.criteria.map(c => c.rating), ['C', '']);
  assert.equal(saved[0].payload.source, undefined);
  await P.page.locator('#pSettings').click();
  await settings.getByRole('button', { name: 'Schlüssel entfernen' }).click();
  await settings.getByText('Kein Schlüssel hinterlegt.', { exact: true }).waitFor();
  await P.page.locator('#pSetBack').click();
  await elternSeite(P.page, 'school');
  await form.getByRole('button', { name: 'Evaluation hinzufügen' }).click();
  await form.getByText('Aus Toddle übernehmen', { exact: true }).click();
  await copied.fill(source);
  await prepare.click();
  await form.getByText(/Hinterlegen Sie zuerst den Claude-Schlüssel/).waitFor();
  assert.equal(await copied.inputValue(), source);
  assert.equal(calls.length, 4);
  await form.getByRole('button', { name: 'Abbrechen', exact: true }).click();
  await P.page.locator('#pSettings').click();
  const devices = P.page.locator('details.psec[data-psec="devices"]');
  if (await devices.getAttribute('open') === null) await devices.locator('summary').click();
  rights.replaceAccount({ ...updated, sequence: 3, devices: [identity.device], children: ['p_other'] });
  await check('', false, true);
  rights.replaceAccount({ ...updated, sequence: 4, devices: [] });
  assert.throws(() => rights.replaceAccount(snapshot));
  await check(oneTimeCode, false, true);
  assert.equal(rights.lookupDevice(identity.account, identity.device).active, false);
  assert.deepEqual(P.errors, []);
});
