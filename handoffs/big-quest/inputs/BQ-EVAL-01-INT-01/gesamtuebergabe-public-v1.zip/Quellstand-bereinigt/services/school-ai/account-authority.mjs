import { kontoStandVerankert } from '../../src/module/konto.mjs';

export function createSchoolAccountAuthority({ directoryAnchor, lookupDevice, directory }) {
  if (typeof directory !== 'function') throw new TypeError('A trusted directory reader is required');
  async function latestAccount(account) {
    const pin = directoryAnchor(account);
    if (!pin) return null;
    return kontoStandVerankert({ zugang: { directory }, account, lookup: pin.lookup, anchor: pin.pub });
  }
  async function currentDevice(account, device) {
    const before = lookupDevice(account, device);
    if (!before?.active || before.validUntil <= Date.now()) return null;
    const latest = await latestAccount(account);
    const after = lookupDevice(account, device);
    if (!after || JSON.stringify(before) !== JSON.stringify(after) ||
      latest?.keyVersion !== after.keyVersion || latest?.accountKey !== after.accountKey) return null;
    return after;
  }
  return { latestAccount, currentDevice };
}
