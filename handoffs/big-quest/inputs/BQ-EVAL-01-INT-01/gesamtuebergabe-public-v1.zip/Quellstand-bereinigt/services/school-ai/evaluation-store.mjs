// The encrypted event, replay receipt and identity become visible in one fast-forward update.
import { createHash } from 'node:crypto';

const shaPattern = /^[0-9a-f]{40}$/;
const digest = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
const wrappedKeyName = /^p_[0-9A-Za-z]{1,40}\.json$/;
const sequenceName = /^([1-9][0-9]{0,8})\.json$/;
const keyVersion = /^[1-9][0-9]{0,8}$/;

export function githubEvaluationStore({ repo, token, branch = 'main', request = fetch, basis = 'https://api.github.com' }) {
  if (!/^[\w-]+\/[\w.-]+$/.test(repo ?? '') || !/^[\w.-]+$/.test(branch) ||
    typeof token !== 'string' || !token || typeof request !== 'function') {
    throw new TypeError('Invalid evaluation storage configuration');
  }
  const api = basis + '/repos/' + repo;
  const ref = encodeURIComponent(branch);

  async function call(path, method = 'GET', body, retryStatuses = []) {
    const response = await request(api + path, {
      method, redirect: 'error', cache: 'no-store',
      headers: { Accept: 'application/vnd.github+json', Authorization: 'Bearer ' + token,
        'X-GitHub-Api-Version': '2022-11-28', ...(body ? { 'Content-Type': 'application/json' } : {}) },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
    if (retryStatuses.includes(response.status)) return null;
    if (!response.ok) throw new Error('Evaluation storage unavailable');
    return response.json();
  }

  function sha(value) {
    if (!shaPattern.test(value ?? '')) throw new Error('Invalid storage version');
    return value;
  }

  async function index(path, head) {
    const file = await call('/contents/' + path.split('/').map(encodeURIComponent).join('/') + '?ref=' + head, 'GET', undefined, [404]);
    if (!file) return null;
    if (file.type !== 'file' || file.encoding !== 'base64') throw new Error('Invalid evaluation index');
    return JSON.parse(Buffer.from(file.content, 'base64').toString('utf8'));
  }

  async function readTree(version) {
    const result = await call('/git/trees/' + version);
    if (result.truncated !== false || !Array.isArray(result.tree)) throw new Error('Incomplete evaluation tree');
    return result.tree;
  }

  async function treeAt(tree, path) {
    for (const segment of path) {
      const next = (await readTree(tree)).find(item => item.path === segment);
      if (!next) return [];
      if (next.type !== 'tree') throw new Error('Invalid evaluation folder');
      tree = sha(next.sha);
    }
    return readTree(tree);
  }

  async function checkKeyVersion(baseTree, head, area, account, version) {
    const files = await treeAt(baseTree, ['keys', area]);
    const keys = await Promise.all(files.filter(file => file.type === 'blob' && wrappedKeyName.test(file.path))
      .map(async file => {
        const record = await index('keys/' + area + '/' + file.path, head);
        const versions = Object.keys(record?.versionen ?? {});
        if (record?.v !== 1 || !versions.length || !versions.every(v => keyVersion.test(v))) {
          throw new Error('Incomplete school key metadata');
        }
        return { name: file.path, latest: Math.max(...versions.map(Number)) };
      }));
    const writer = keys.find(key => key.name === account + '.json');
    if (!writer) return 'EVALUATION_KEY_MISSING';
    // During rotation, recipients' wrapped keys appear one at a time. Once a newer
    // version is visible, no new event may be encrypted with the previous version.
    if (writer.latest !== version || keys.some(key => key.latest > version)) return 'EVALUATION_KEY_OUTDATED';
    return null;
  }

  return async function save(grant, input) {
    const { family, child, account, device, current } = grant;
    const { operation, identity, bundle } = input;
    const area = 'schule:' + child;
    const areaPath = 'events/' + area;
    // These opaque indexes follow existing recursive removal of the school area.
    const opPath = areaPath + '/evaluation/operations/' + digest([family, account, device, operation]) + '.json';
    const identityPath = identity && areaPath + '/evaluation/identities/' + digest([family, identity]) + '.json';
    const hash = digest(input);

    for (let attempt = 0; attempt < 5; attempt++) {
      if (!await current()) return { error: 'ACCESS_DENIED' };
      const head = sha((await call('/git/ref/heads/' + ref)).object?.sha);
      const previous = await index(opPath, head);
      if (previous) return previous.hash === hash ? previous.result : { error: 'OPERATION_CONFLICT' };
      const matching = identityPath ? await index(identityPath, head) : null;
      const baseTree = sha((await call('/git/commits/' + head)).tree?.sha);
      const items = [];
      let result;
      if (matching) {
        result = { status: 'existing', event: matching.event };
      } else {
        const invalidKey = await checkKeyVersion(baseTree, head, area, account, bundle.kv);
        if (invalidKey) return { error: invalidKey };

        const files = await treeAt(baseTree, ['events', area, device]);
        const numbers = files.filter(file => file.type === 'blob')
          .map(file => sequenceName.exec(file.path)?.[1]).filter(Boolean).map(Number);
        const number = numbers.reduce((max, value) => Math.max(max, value), 0) + 1;
        if (number > 999_999_999 || number !== numbers.length + 1) throw new Error('Invalid device sequence');
        if (files.some(file => file.path === number + '.json')) throw new Error('Occupied device event slot');

        const event = bundle.eintraege[0].id;
        items.push([areaPath + '/' + device + '/' + number + '.json', bundle]);
        if (identityPath) items.push([identityPath, { event }]);
        result = { status: 'saved', event };
      }
      items.push([opPath, { hash, result }]);
      const tree = sha((await call('/git/trees', 'POST', {
        base_tree: baseTree,
        tree: items.map(([path, data]) => ({ path, mode: '100644', type: 'blob', content: JSON.stringify(data) })),
      })).sha);
      const commit = sha((await call('/git/commits', 'POST', {
        message: 'bq: confirmed school evaluation', tree, parents: [head],
      })).sha);
      if (!await current()) return { error: 'ACCESS_DENIED' };
      if (await call('/git/refs/heads/' + ref, 'PATCH', { sha: commit, force: false }, [409, 422])) return result;
    }
    throw new Error('Concurrent storage update; retry required');
  };
}
