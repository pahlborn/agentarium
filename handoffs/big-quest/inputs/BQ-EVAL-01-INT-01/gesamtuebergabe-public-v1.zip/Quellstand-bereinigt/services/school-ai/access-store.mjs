import { createHash, randomBytes } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { chmodSync, closeSync, openSync } from 'node:fs';

const accessId = /^[A-Za-z0-9_-]{1,128}$/;

export function openSchoolAccessStore(path) {
  if (path !== ':memory:') {
    closeSync(openSync(path, 'a', 0o600));
    chmodSync(path, 0o600);
  }
  const db = new DatabaseSync(path);
  db.exec(`
    PRAGMA busy_timeout=5000;
    CREATE TABLE IF NOT EXISTS authority (
      account TEXT NOT NULL, device TEXT NOT NULL, data TEXT NOT NULL,
      PRIMARY KEY (account, device)
    );
    CREATE TABLE IF NOT EXISTS account_version (
      account TEXT PRIMARY KEY, family TEXT NOT NULL, sequence INTEGER NOT NULL,
      key_version INTEGER NOT NULL, account_key TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS revoked_child (
      account TEXT NOT NULL, child TEXT NOT NULL, PRIMARY KEY (account, child)
    );
    CREATE TABLE IF NOT EXISTS account_anchor (
      account TEXT PRIMARY KEY, data TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS access_state (
      kind TEXT NOT NULL, key TEXT NOT NULL, expires INTEGER NOT NULL, data TEXT NOT NULL,
      PRIMARY KEY (kind, key)
    );
    CREATE TABLE IF NOT EXISTS claude_key (
      family TEXT PRIMARY KEY, version TEXT NOT NULL, data TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS claude_attempt (
      family TEXT NOT NULL, request_id TEXT NOT NULL, started INTEGER NOT NULL,
      PRIMARY KEY (family, request_id)
    );
    CREATE INDEX IF NOT EXISTS claude_attempt_started ON claude_attempt (family, started);
  `);
  const read = db.prepare('SELECT data FROM authority WHERE account=? AND device=?');
  const put = db.prepare('INSERT OR REPLACE INTO authority VALUES (?, ?, ?)');
  function lookupDevice(account, device) {
    const found = read.get(account, device);
    return found ? JSON.parse(found.data) : null;
  }
  // The operator supplies a complete, verified account snapshot. Devices omitted from it are revoked.
  function replaceAccount({ account, family, keyVersion, accountKey, validUntil, children, devices, sequence, directoryAnchor }) {
    if (![account, family].every(x => typeof x === 'string' && accessId.test(x)) ||
      !Number.isSafeInteger(keyVersion) || keyVersion < 1 || typeof accountKey !== 'string' || !accountKey ||
      !Number.isSafeInteger(sequence) || sequence < 1 || !Number.isSafeInteger(validUntil) || !Array.isArray(children) || children.some(x => typeof x !== 'string' || !accessId.test(x)) ||
      !Array.isArray(devices) || devices.some(x => typeof x !== 'string' || !accessId.test(x)) ||
      new Set(devices).size !== devices.length) throw new TypeError('Invalid authority snapshot');
    if (directoryAnchor !== undefined && (!/^v[a-f0-9]{64}$/.test(directoryAnchor.lookup ?? '') ||
      typeof directoryAnchor.pub?.ecdsa !== 'string' || typeof directoryAnchor.pub?.ecdh !== 'string')) throw new TypeError('Invalid directory anchor');
    db.exec('BEGIN IMMEDIATE');
    try {
      const previous = db.prepare('SELECT data FROM authority WHERE account=?').all(account).map(x => JSON.parse(x.data));
      const version = db.prepare('SELECT * FROM account_version WHERE account=?').get(account);
      if (version && (version.sequence >= sequence || version.key_version > keyVersion || version.family !== family ||
        (version.key_version === keyVersion && version.account_key !== accountKey))) throw new Error('Authority snapshot conflicts with account history');
      if (directoryAnchor) {
        const pinned = db.prepare('SELECT data FROM account_anchor WHERE account=?').get(account);
        const value = JSON.stringify({ lookup: directoryAnchor.lookup, pub: { ecdh: directoryAnchor.pub.ecdh, ecdsa: directoryAnchor.pub.ecdsa } });
        if (pinned && pinned.data !== value) throw new Error('Directory anchor is already pinned');
        db.prepare('INSERT OR IGNORE INTO account_anchor VALUES (?, ?)').run(account, value);
      }
      db.prepare('INSERT OR REPLACE INTO account_version VALUES (?, ?, ?, ?, ?)').run(account, family, sequence, keyVersion, accountKey);
      const revoked = db.prepare('SELECT child FROM revoked_child WHERE account=?').all(account);
      if (revoked.some(row => children.includes(row.child))) throw new Error('A removed child cannot be restored by import');
      for (const device of devices) {
        const old = previous.find(x => x.device === device);
        if (old && !old.active) throw new Error('A revoked device must use a new device ID');
        put.run(account, device, JSON.stringify({
          account, device, family, keyVersion, accountKey, validUntil, children, sequence, role: 'parent', active: true,
          deviceVersion: old?.deviceVersion ?? 1, deviceKey: old?.deviceKey ?? null,
        }));
      }
      for (const old of previous) if (!devices.includes(old.device) && old.active) {
        put.run(account, old.device, JSON.stringify({ ...old, sequence, active: false, deviceVersion: old.deviceVersion + 1 }));
      }
      db.exec('COMMIT');
    } catch (error) {
      db.exec('ROLLBACK');
      throw error;
    }
  }
  const update = db.prepare('UPDATE authority SET data=? WHERE account=? AND device=? AND data=?');
  const codeHash = code => createHash('sha256').update(code).digest('hex');
  function issueCode(account, device, now = Date.now()) {
    const row = lookupDevice(account, device);
    if (!row?.active || row.deviceKey || row.validUntil <= now) throw new Error('Device is not eligible for enrollment');
    const code = randomBytes(20).toString('base64url');
    const updated = { ...row, enrollment: { hash: codeHash(code), until: Math.min(row.validUntil, now + 600_000) } };
    if (update.run(JSON.stringify(updated), account, device, JSON.stringify(row)).changes !== 1) throw new Error('Authority changed');
    return code;
  }
  function bindDevice(expected, deviceKey, code, now) {
    if (typeof code !== 'string' || !/^[A-Za-z0-9_-]{27}$/.test(code) || expected.deviceKey ||
      !expected.enrollment || expected.enrollment.until <= now || expected.enrollment.hash !== codeHash(code)) return false;
    const { enrollment, ...updated } = { ...expected, deviceKey };
    return update.run(JSON.stringify(updated), expected.account, expected.device, JSON.stringify(expected)).changes === 1;
  }
  function directoryAnchor(account) {
    const row = db.prepare('SELECT data FROM account_anchor WHERE account=?').get(account);
    return row ? JSON.parse(row.data) : null;
  }
  // A signed reconciliation can only remove rights already known to this account.
  function reconcile(expected, latest, removedDevices, removedChildren, at) {
    db.exec('BEGIN IMMEDIATE');
    try {
      const actual = lookupDevice(expected.account, expected.device);
      const verified = db.prepare('SELECT key_version FROM account_version WHERE account=?').get(expected.account);
      if (JSON.stringify(actual) !== JSON.stringify(expected) || actual.validUntil <= at ||
        !actual.active || actual.keyVersion !== verified?.key_version || removedDevices.includes(actual.device) || latest.keyVersion < actual.keyVersion) {
        db.exec('ROLLBACK');
        return false;
      }
      const excluded = db.prepare('INSERT OR IGNORE INTO revoked_child VALUES (?, ?)');
      for (const child of removedChildren) if (actual.children.includes(child)) excluded.run(actual.account, child);
      const rows = db.prepare('SELECT data FROM authority WHERE account=?').all(actual.account).map(x => JSON.parse(x.data));
      for (const row of rows) {
        if (!row.active) continue;
        const removed = removedDevices.includes(row.device);
        put.run(row.account, row.device, JSON.stringify({
          ...row, ...(row.device === actual.device ? latest : {}),
          ...(latest.keyVersion > row.keyVersion ? { enrollment: undefined } : {}), active: !removed, deviceVersion: row.deviceVersion + Number(removed),
          children: row.children.filter(child => !removedChildren.includes(child)),
        }));
      }
      db.prepare('UPDATE account_version SET key_version=?, account_key=? WHERE account=?')
        .run(latest.keyVersion, latest.accountKey, actual.account);
      db.exec('COMMIT');
      return true;
    } catch (error) {
      db.exec('ROLLBACK');
      throw error;
    }
  }
  function state(kind) {
    const get = db.prepare('SELECT data FROM access_state WHERE kind=? AND key=?');
    const insert = db.prepare('INSERT OR IGNORE INTO access_state VALUES (?, ?, ?, ?)');
    const take = db.prepare('DELETE FROM access_state WHERE kind=? AND key=? RETURNING data');
    return {
      get(key) {
        const row = get.get(kind, key);
        return row ? JSON.parse(row.data) : null;
      },
      take(key) {
        const row = take.get(kind, key);
        return row ? JSON.parse(row.data) : null;
      },
      put(key, data) {
        return insert.run(kind, key, data.expires, JSON.stringify(data)).changes === 1;
      },
      prune(at) { db.prepare('DELETE FROM access_state WHERE kind=? AND expires<=?').run(kind, at); },
      size() { return db.prepare('SELECT count(*) AS n FROM access_state WHERE kind=?').get(kind).n; },
    };
  }
  const getClaudeKey = db.prepare('SELECT data FROM claude_key WHERE family=?');
  const getClaudeVersion = db.prepare('SELECT version FROM claude_key WHERE family=?');
  const putClaudeKey = db.prepare('INSERT OR REPLACE INTO claude_key VALUES (?, ?, ?)');
  const deleteClaudeKey = db.prepare('DELETE FROM claude_key WHERE family=?');
  const pruneClaudeAttempts = db.prepare('DELETE FROM claude_attempt WHERE started<=?');
  const getClaudeAttempt = db.prepare('SELECT 1 FROM claude_attempt WHERE family=? AND request_id=?');
  const countClaudeAttempts = db.prepare('SELECT count(*) AS n FROM claude_attempt WHERE family=? AND started>?');
  const putClaudeAttempt = db.prepare('INSERT INTO claude_attempt VALUES (?, ?, ?)');
  const claudeStore = {
    localOnly: true,
    readKey(family) {
      const row = getClaudeKey.get(family);
      return row ? JSON.parse(row.data) : null;
    },
    keyVersion(family) { return getClaudeVersion.get(family)?.version ?? null; },
    writeKey(family, record) { putClaudeKey.run(family, record.version, JSON.stringify(record)); },
    removeKey(family) { deleteClaudeKey.run(family); },
    reserveAttempt(family, requestId, now) {
      db.exec('BEGIN IMMEDIATE');
      try {
        pruneClaudeAttempts.run(now - 86_400_000);
        let error = null;
        if (getClaudeAttempt.get(family, requestId)) error = 'REQUEST_ALREADY_USED';
        else if (countClaudeAttempts.get(family, now - 60_000).n >= 4 ||
          countClaudeAttempts.get(family, now - 86_400_000).n >= 40) error = 'LIMIT';
        else putClaudeAttempt.run(family, requestId, now);
        db.exec('COMMIT');
        return error;
      } catch (error) {
        db.exec('ROLLBACK');
        throw error;
      }
    },
  };
  return { lookupDevice, replaceAccount, issueCode, bindDevice, directoryAnchor, reconcile, state, claudeStore, close: () => db.close() };
}
