import { createServer } from 'node:http';
import { createSchoolClaude, schoolClaudeRoute } from './claude-routes.mjs';
import { schoolRightsSync } from './rights-sync.mjs';
import { createEvaluationRoutes, schoolEvaluationRoute, EVALUATION_BODY_LIMIT } from './evaluation-routes.mjs';
import { createSchoolSessions } from './session.mjs';

const MAX_BODY = 4096;
const sessionRoutes = new Set(['/v1/session/challenge', '/v1/session']);

async function readBody(request, maxBody) {
  const chunks = [];
  let length = 0;
  for await (const chunk of request.iterator({ destroyOnReturn: false })) {
    length += chunk.length;
    if (length > maxBody) {
      request.resume();
      return null;
    }
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

const jsonContent = request => /^application\/json(?:\s*;|$)/i.test(request.headers['content-type'] ?? '');

async function readJson(request) {
  if (!jsonContent(request)) return null;
  const raw = await readBody(request, MAX_BODY);
  if (!raw) return null;
  try {
    const value = JSON.parse(raw.toString('utf8'));
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
  } catch {
    return null;
  }
}

// HTTPS terminates at the configured service boundary. Enrollment is provided by the caller.
export function createSchoolSessionServer({ origin, audience, lookupDevice, bindDevice, state, now, testLoopback = false, directoryAuthority, reconcile, claude, evaluations }) {
  const sessions = createSchoolSessions({ origin, audience, lookupDevice: directoryAuthority?.currentDevice ?? lookupDevice, bindDevice, state, now, testLoopback });
  const sync = directoryAuthority && schoolRightsSync({ origin, audience, lookupDevice, latestAccount: directoryAuthority.latestAccount, reconcile, state, now });
  const loopback = testLoopback && [origin, audience].every(url => /^http:\/\/127\.0\.0\.1:\d+$/.test(url));
  if (claude && !loopback && (!directoryAuthority || !state)) throw new TypeError('Claude requires authoritative rights and durable sessions');
  const callClaude = claude && createSchoolClaude({ ...claude, scope: JSON.stringify([origin, audience]), now, testLoopback: loopback });
  if (evaluations && !loopback && (!directoryAuthority || !state)) throw new TypeError('Evaluations require authoritative rights and durable sessions');
  const callEvaluation = evaluations && createEvaluationRoutes(evaluations);
  return createServer({ requestTimeout: 10_000 }, async (request, response) => {
    response.setHeader('Cache-Control', 'no-store');
    response.setHeader('Vary', 'Origin');
    response.setHeader('X-Content-Type-Options', 'nosniff');
    const send = (status, body) => {
      response.statusCode = status;
      if (body === undefined) return response.end();
      response.setHeader('Content-Type', 'application/json; charset=utf-8');
      response.end(JSON.stringify(body));
    };
    const access = /^\/v1\/children\/([A-Za-z0-9_-]{1,128})\/access$/.exec(request.url);
    const syncRequest = sync && request.url === '/v1/session/rights';
    const claudeRoute = callClaude && schoolClaudeRoute(request.url);
    const evaluationRoute = callEvaluation && schoolEvaluationRoute(request.url);
    if (!sessionRoutes.has(request.url) && !access && !syncRequest && !claudeRoute && !evaluationRoute) return send(404);
    if (request.headers.origin !== origin) return claudeRoute || evaluationRoute ? send(403, { error: 'ACCESS_DENIED' }) : send(403);
    response.setHeader('Access-Control-Allow-Origin', origin);
    if (claudeRoute || evaluationRoute) {
      const methods = evaluationRoute ? ['POST'] : claudeRoute.methods;
      if (request.method === 'OPTIONS') {
        response.setHeader('Access-Control-Allow-Methods', [...methods, 'OPTIONS'].join(', '));
        response.setHeader('Access-Control-Allow-Headers',
          'Content-Type, Authorization, X-BQ-At, X-BQ-Nonce, X-BQ-Signature, X-BQ-Account-Signature');
        return send(204);
      }
      if (!methods.includes(request.method)) return send(405, { error: 'INVALID_INPUT' });
      try {
        const hasJson = request.method === 'PUT' || request.method === 'POST';
        if (hasJson && !jsonContent(request)) return send(400, { error: 'INVALID_INPUT' });
        const maxBody = evaluationRoute?.action === 'evaluations' ? EVALUATION_BODY_LIMIT : 48_000;
        const body = await readBody(request, hasJson ? maxBody : 0);
        if (!body) return send(400, { error: 'INVALID_INPUT' });
        if (evaluationRoute) return await callEvaluation({ route: evaluationRoute, request, body, sessions, origin, send });
        return await callClaude({ route: claudeRoute, request, body, sessions, origin, send });
      } catch {
        return send(503, { error: 'UNAVAILABLE' });
      }
    }
    if (request.method === 'OPTIONS') {
      response.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
      response.setHeader('Access-Control-Allow-Headers', 'Content-Type');
      return send(204);
    }
    if (request.method !== 'POST') return send(405);
    try {
      const input = await readJson(request);
      if (!input) return send(400);
      if (syncRequest) return await sync(input) ? send(204) : send(403);
      if (access) {
        if (Object.keys(input).some(key => !['token', 'at', 'nonce', 'signature'].includes(key))) return send(400);
        const granted = await sessions.authorize({
          origin, token: input.token, at: input.at, nonce: input.nonce, signature: input.signature, child: access[1], path: request.url, method: request.method, body: Buffer.alloc(0),
        });
        return granted ? send(200, { allowed: true }) : send(403);
      }
      const result = request.url === '/v1/session/challenge'
        ? await sessions.challenge({ origin, account: input.account, device: input.device, deviceKey: input.deviceKey })
        : await sessions.open({ origin, id: input.id, accountProof: input.accountProof, deviceProof: input.deviceProof, enrollmentCode: input.enrollmentCode });
      return result ? send(200, result) : send(403);
    } catch {
      return send(503);
    }
  });
}
