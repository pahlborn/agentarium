import { verifyBytes } from '../../src/module/krypto.mjs';

const rightsId = /^[A-Za-z0-9_-]{1,128}$/;
const lifetime = 60_000;
const validList = list => Array.isArray(list) && list.length <= 128 &&
  list.every(item => typeof item === 'string' && rightsId.test(item)) && new Set(list).size === list.length;

export function schoolRightsSync({ origin, audience, lookupDevice, latestAccount, reconcile, state, now = Date.now }) {
  const seen = state('rights:' + JSON.stringify([origin, audience]));
  return async function sync(input) {
    const { account, device, keyVersion, rotation, removedDevices, removedChildren, at, nonce, accountProof, deviceProof } = input;
    if (![account, device].every(id => typeof id === 'string' && rightsId.test(id)) ||
      typeof rotation !== 'boolean' || !Number.isSafeInteger(keyVersion) || !Number.isSafeInteger(at) || Math.abs(now() - at) > lifetime ||
      typeof nonce !== 'string' || !/^[A-Za-z0-9_-]{32}$/.test(nonce) ||
      !validList(removedDevices) || !validList(removedChildren) || removedDevices.includes(device) ||
      ![accountProof, deviceProof].every(sig => typeof sig === 'string' && sig.length <= 128)) return false;
    const row = lookupDevice(account, device);
    if (!row?.active || !row.deviceKey || row.validUntil <= now()) return false;
    const message = JSON.stringify(['bq-school-ai', 1, 'rights-reduce', origin, audience,
      row.family, account, device, keyVersion, rotation, removedDevices, removedChildren, at, nonce]);
    if (!await verifyBytes({ ecdsa: row.deviceKey }, message, deviceProof)) return false;
    const latest = await latestAccount(account);
    if (latest?.keyVersion !== keyVersion || keyVersion < row.keyVersion || (keyVersion > row.keyVersion && !rotation) ||
      !await verifyBytes({ ecdsa: latest.accountKey }, message, accountProof) ||
      Math.abs(now() - at) > lifetime) return false;
    // A known device can be revoked only with the key rotation used by Big Quest.
    // Rotations without a known target may be recovery or an ordinary password/key change.
    if (removedDevices.some(id => lookupDevice(account, id)?.active) && keyVersion <= row.keyVersion) return false;
    seen.prune(now());
    if (seen.size() >= 65_536 || !seen.put(account + ':' + device + ':' + nonce, { expires: at + lifetime + 1 })) return false;
    return reconcile(row, latest, removedDevices, removedChildren, now());
  };
}
