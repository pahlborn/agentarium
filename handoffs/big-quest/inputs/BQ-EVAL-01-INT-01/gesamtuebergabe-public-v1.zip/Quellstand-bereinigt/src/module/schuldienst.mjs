import { bytesToB64, signBytes } from './krypto.mjs';

function sdKeys(account, device) {
  return new Promise((resolve, reject) => {
    const open = indexedDB.open('bq2_schuldienst', 1);
    open.onupgradeneeded = () => open.result.createObjectStore('geraete');
    open.onerror = () => reject(open.error);
    open.onsuccess = async () => {
      const db = open.result;
      const id = JSON.stringify([account, device]);
      try {
        const candidate = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign', 'verify']);
        const keys = await new Promise((done, fail) => {
          const tx = db.transaction('geraete', 'readwrite');
          const store = tx.objectStore('geraete');
          const read = store.get(id);
          let result;
          read.onsuccess = () => { result = read.result ?? candidate; if (!read.result) store.add(result, id); };
          tx.oncomplete = () => done(result);
          tx.onabort = () => fail(tx.error);
        });
        resolve(keys);
      } catch (error) { reject(error); }
      finally { db.close(); }
    };
  });
}
const sdBase64Url = bytes => bytesToB64(bytes).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const sdHash = async value => sdBase64Url(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value))));

async function sdSession({ endpoint, account, device, enrollmentCode, current }) {
  const audience = new URL(endpoint).origin;
  if (endpoint !== audience || !/^(?:https:\/\/|http:\/\/127\.0\.0\.1:\d+$)/.test(audience)) throw new Error('Invalid service origin');
  const origin = location.origin;
  const check = () => { if (!current()) throw new Error('Account changed'); };
  const post = async (path, body) => {
    check();
    const response = await fetch(audience + path, {
      method: 'POST', mode: 'cors', credentials: 'omit', redirect: 'error', cache: 'no-store',
      headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    });
    check();
    if (!response.ok) throw new Error('Service access denied');
    return response.json();
  };
  const keys = await sdKeys(account.kennung, device);
  const deviceKey = bytesToB64(new Uint8Array(await crypto.subtle.exportKey('spki', keys.publicKey)));
  const pending = await post('/v1/session/challenge', { account: account.kennung, device, deviceKey });
  const [namespace, version, action, issuedOrigin, issuedAudience, person, boundDevice, stand, , id, expires, key] = JSON.parse(pending.message);
  if (namespace !== 'bq-school-ai' || version !== 1 || action !== 'login' || issuedOrigin !== origin ||
    issuedAudience !== audience || person !== account.kennung || boundDevice !== device ||
    stand !== (account.stand ?? 1) || id !== pending.id || expires !== pending.expires || expires <= Date.now() ||
    key !== deviceKey) throw new Error('Invalid challenge');
  const session = await post('/v1/session', {
    id, accountProof: await signBytes(account.schluessel, pending.message),
    deviceProof: await signBytes({ ecdsa: keys }, pending.message), enrollmentCode,
  });
  if (session.origin !== origin || session.audience !== audience || !/^[A-Za-z0-9_-]{43}$/.test(session.token)) throw new Error('Invalid session');
  return { audience, origin, check, post, keys, token: session.token, expires: session.expires };
}

async function sdProof(session, method, path, body, accountKey) {
  const { token, origin, audience, keys } = session;
  const at = Date.now(), nonce = sdBase64Url(crypto.getRandomValues(new Uint8Array(24)));
  const message = JSON.stringify(['bq-school-ai', 1, 'request', origin, audience,
    await sdHash(token), method, path, await sdHash(body), at, nonce]);
  const signature = await signBytes({ ecdsa: keys }, message);
  const accountSignature = accountKey ? await signBytes(accountKey, message) : null;
  return { token, at, nonce, signature, accountSignature };
}

export async function schuldienstZugang(context) {
  const { child } = context;
  if (!/^[A-Za-z0-9_-]{1,128}$/.test(child)) throw new Error('Invalid child');
  const session = await sdSession(context);
  const path = '/v1/children/' + child + '/access';
  const { token, at, nonce, signature } = await sdProof(session, 'POST', path, '');
  const result = await session.post(path, { token, at, nonce, signature });
  session.check();
  return result.allowed === true;
}

let sdClaudeSession = null;

export function schuldienstClaudeAbmelden() {
  sdClaudeSession = null;
}

async function sdClaudeLogin(context) {
  const { endpoint, account, device, current } = context;
  if (!current()) throw new Error('ACCESS_DENIED');
  let entry = sdClaudeSession;
  if (entry?.endpoint !== endpoint || entry.account !== account.schluessel || entry.device !== device ||
    entry.expires <= Date.now() + 5000) {
    entry = { endpoint, account: account.schluessel, device, expires: Infinity, pending: sdSession(context) };
    sdClaudeSession = entry;
  }
  try {
    const session = await entry.pending;
    entry.expires = session.expires;
    if (sdClaudeSession !== entry || !current()) throw new Error('ACCESS_DENIED');
    return { session, entry };
  } catch (error) {
    if (sdClaudeSession === entry) sdClaudeSession = null;
    throw error;
  }
}

export async function schuldienstClaude(context, action, value) {
  let method, path, payload;
  switch (action) {
    case 'status':
      method = 'GET'; path = '/v1/family/claude-key/status';
      break;
    case 'save':
      method = 'PUT'; path = '/v1/family/claude-key'; payload = { apiKey: value };
      break;
    case 'delete':
      method = 'DELETE'; path = '/v1/family/claude-key';
      break;
    case 'draft':
      if (!/^[A-Za-z0-9_-]{1,128}$/.test(context.child)) throw new Error('ACCESS_DENIED');
      method = 'POST'; path = '/v1/children/' + context.child + '/evaluation-drafts';
      payload = { requestId: crypto.randomUUID(), source: value };
      break;
    default: throw new Error('INVALID_INPUT');
  }
  return sdProtectedRequest(context, method, path, payload, action === 'save' || action === 'delete');
}

export function schuldienstEvaluation(context, action, payload) {
  if (!/^p_[A-Za-z0-9]{1,40}$/.test(context.child) ||
    !['evaluations', 'evaluation-keys', 'evaluation-list', 'evaluation-bundle'].includes(action)) {
    throw new Error('INVALID_INPUT');
  }
  return sdProtectedRequest(context, 'POST', '/v1/children/' + context.child + '/' + action, payload,
    action === 'evaluations');
}

async function sdProtectedRequest(context, method, path, payload, proveAccount) {
  const body = payload ? JSON.stringify(payload) : '';
  const { session, entry } = await sdClaudeLogin(context);
  const accountKey = proveAccount ? context.account.schluessel : null;
  const { token, at, nonce, signature, accountSignature } = await sdProof(session, method, path, body, accountKey);
  const headers = {
    Authorization: 'Bearer ' + token, 'X-BQ-At': String(at),
    'X-BQ-Nonce': nonce, 'X-BQ-Signature': signature,
  };
  if (accountSignature) headers['X-BQ-Account-Signature'] = accountSignature;
  if (body) headers['Content-Type'] = 'application/json';
  if (!context.current() || sdClaudeSession !== entry) throw new Error('ACCESS_DENIED');
  const response = await fetch(session.audience + path, {
    method, headers, body: body || undefined,
    mode: 'cors', credentials: 'omit', redirect: 'error', cache: 'no-store',
  });
  const result = await response.json();
  if (!context.current() || sdClaudeSession !== entry) throw new Error('ACCESS_DENIED');
  if (!response.ok) {
    if (response.status === 401 || response.status === 403) sdClaudeSession = null;
    throw new Error(result.error);
  }
  return result;
}

/* Queue only identifiers. On retry the active account signs with its current keys. */
export function schuldienstVormerken(account, device, children = [], rotation = false) {
  const slot = 'bq2_' + account.kennung + '__schuldienst';
  const queued = schuldienstWartend(slot);
  children = children.filter(child => !queued.reportedChildren?.includes(child) && !queued.children.includes(child));
  if (device) queued.devices = [...new Set([...queued.devices, device])];
  queued.children = [...new Set([...queued.children, ...children])];
  if (rotation || device || children.length) {
    queued.rotation = queued.rotation || rotation;
    try { localStorage.setItem(slot, JSON.stringify(queued)); } catch { /* service remains locked on rotation */ }
  }
}

function schuldienstWartend(slot) {
  try {
    const value = JSON.parse(localStorage.getItem(slot));
    if (Array.isArray(value?.devices) && Array.isArray(value.children)) return value;
  } catch { /* storage is unavailable */ }
  return { devices: [], children: [] };
}

const sdSyncing = new Set();
export async function schuldienstRechteAbgleichen({ endpoint, account, device, family, current }) {
  const slot = 'bq2_' + account.kennung + '__schuldienst';
  const saved = localStorage.getItem(slot), queued = schuldienstWartend(slot);
  if ((!queued.rotation && !queued.devices.length && !queued.children.length) || sdSyncing.has(slot)) return;
  sdSyncing.add(slot);
  try {
    const keys = await sdKeys(account.kennung, device);
    const at = Date.now(), nonce = sdBase64Url(crypto.getRandomValues(new Uint8Array(24)));
    const { devices: removedDevices, children: removedChildren } = queued;
    const keyVersion = account.stand ?? 1;
    const message = JSON.stringify(['bq-school-ai', 1, 'rights-reduce', location.origin, endpoint,
      family, account.kennung, device, keyVersion, queued.rotation === true, removedDevices, removedChildren, at, nonce]);
    const [accountProof, deviceProof] = await Promise.all([
      signBytes(account.schluessel, message), signBytes({ ecdsa: keys }, message),
    ]);
    if (!current()) return;
    const result = await fetch(endpoint + '/v1/session/rights', {
      method: 'POST', mode: 'cors', credentials: 'omit', redirect: 'error', cache: 'no-store',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ account: account.kennung, device, keyVersion, rotation: queued.rotation === true, removedDevices, removedChildren,
        at, nonce, accountProof, deviceProof }),
    });
    if (result.status === 204 && localStorage.getItem(slot) === saved) {
      localStorage.setItem(slot, JSON.stringify({ devices: [], children: [],
        reportedChildren: [...new Set([...(queued.reportedChildren ?? []), ...queued.children])] }));
    }
  } finally {
    sdSyncing.delete(slot);
  }
}
