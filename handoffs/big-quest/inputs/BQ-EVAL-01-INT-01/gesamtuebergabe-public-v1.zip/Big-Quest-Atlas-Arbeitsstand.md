# Big Quest · aktueller Atlas-Arbeitsstand

**Stand 14.11.2026 · BQ-EVAL-01 · zuständig Atlas**

## Startblock für jeden neuen Atlas-Auftrag

> Atlas, lade und verwende `operate-as-atlas`. Übernimm Big Quest (`BQ-EVAL-01`, `pahlborn/bis-school-app_src`). Öffne zuerst den [aktuellen Atlas-Arbeitsstand](https://chatgpt.com/library?file_id=libfile_d8cb0a8a93ec8191b7af47dc549bbedd&account_id=personal). Prüfe die tatsächlich geltenden Agentarium-Regeln und nenne zu Beginn Regelstand, Entwicklungsbasis, Auftrag und Grenzen. Nutze die dort verlinkten Nachweise gezielt. Arbeite im bestehenden Monitor-Projekt `big-quest` im Archivmodus, solange Peter keinen Livebetrieb anfordert. Halte die tatsächlichen Schritte so fest, dass sie später im Monitor aus dem Archiv nachvollzogen werden können.
>
> Verwende den folgenden Epic-/Story-Auftrag als Arbeitsumfang. Prüfe die angegebenen Referenzen vor Änderungen. Frage Peter bei einer fehlenden Entscheidung zu Produktumfang, Bedienung oder Architektur gezielt, bevor du davon betroffene Änderungen vornimmst. Aktualisiere nach jedem wesentlichen Schritt diesen Arbeitsstand mit prüfbarem Beleg und nächstem Schritt. Dokumentiere pro Story in der Release-Doku, was umgesetzt und am angegebenen Stand geprüft wurde.

Gib diesen Startblock bei jedem neuen Entwicklungsauftrag mit, gefolgt von Epic, Story-IDs, exakter Basis, Abnahme und den für den Auftrag geltenden Grenzen.

## Verbindliche Referenzen
- Produktentscheidungen: [Umsetzungskonzept v1.0](https://chatgpt.com/library?file_id=libfile_456694f023b481919eca635c3ceae706&account_id=personal). Toddle direkt öffnen, Eltern melden sich dort selbst an und fügen Text in Big Quest ein. Rechte und Datenschutz hat Peter für diesen Ablauf als geklärt bestätigt. Ein einmal gespeicherter Claude-API-Schlüssel pro Familie. Kein neuer Machbarkeitspilot.
- Formular: [PR #192](https://github.com/pahlborn/bis-school-app_src/pull/192) und [Test 11 / PR #198](https://github.com/pahlborn/bis-school-app_src/pull/198) als erprobte Funktions- und Bedienreferenz. Für dieses Formular Texte, Darstellung und Bedienung bei der Übernahme bewahren. Technisch nötige Änderungen am Browser-Einstieg begründen. Der Quellbranch für die Integration ist eine separate Entscheidung.
- Quellrepo: `pahlborn/bis-school-app_src`. Letztes geprüftes `main`: `7995d6968e3895b88f8ed2c3b0476683e5720c1a`. Beim nächsten Entwicklungsauftrag erneut prüfen.
- Letzter lokaler Entwicklungsstand: `9fbd987d4d3f02b1ac890bc0fe508f0bfa73a3e0`, Baum `7493d82b02769d7d0511c66b01f7fe1abc257f67`. [Entwicklungsstand 05 mit kumulativem und inkrementellem Patch](https://chatgpt.com/library?file_id=libfile_2d990d0cfd74819189f57f77a8ee37e6&account_id=personal) · [Epic-/Story-/Release-Doku](https://chatgpt.com/library?file_id=libfile_23e53d80bfb881918aa63b7e4b3087ac&account_id=personal). EP-04 / US-401, 402 und 403 lokal integriert und mit simuliertem Claude geprüft. Schlüsselstatus pro Familie, verschlüsselter lokaler Tresor, Aufbereitung im Test-11-Formular, Bestätigung als einziger Schreib-Trigger. 406 lokale Prüfungen und Testbuild grün. Wiederherstellung auf main oder auf dem Baum aus Entwicklungsstand 04.
- Agentarium: Archivspur im Projekt `big-quest`, Lauf `BQ-EVAL-01`. [Letzte Entwicklungsübergabe](https://github.com/pahlborn/agentarium/issues/2#issuecomment-6879503934). In der bisherigen Sitzung ohne Livebetrieb gearbeitet.

## Nächster Entwicklungsschritt
1. Gemäß Konzept EP-06 / US-601–603 fortsetzen. Geschützten Speicheradapter und Abgleich am vorhandenen bestätigten Bewertungspfad aufbauen. Der EP-04-Dienst ist lokal verfügbar. Die produktive Aktivierung braucht die vorgesehenen Adapter für verwalteten KMS, Datenbank und Startkonfiguration sowie die Prüfung der Anbieterintegration und des Löschschutzes bei Wiederherstellung.
2. US-203 Betriebsgrenze: geprüfter Verzeichnisanker und Erstimport erforderlich. Signierte Browser-Meldungen reduzieren bestehende Rechte pro Konto. Erstfreigabe, neue Freigaben und Wiederfreigabe weiterer Altgeräte nach Rotation bleiben Betreiberaufgaben. Gerätelink [#194](https://github.com/pahlborn/bis-school-app_src/pull/194) bleibt separat offen. Den Epic-/Story-Nachweis bei jeder Lieferung aktualisieren.
3. GitHub Actions sind ausgeschöpft. Bis zu einer neuen Entscheidung lokal arbeiten. GitHub-Publikation und produktive Änderungen benötigen die entsprechende Freigabe. Im Konfliktfall jüngste ausdrückliche Entscheidung von Peter anwenden.
4. Nach jedem wesentlichen Schritt diesen **selben** Arbeitsstand aktualisieren. Stand, freigegebener Umfang, genaue Referenz, Ergebnisbeleg, offene Entscheidung und nächster Schritt gehören hierher. Bestehende Belege verlinken. Der Start eines neuen Chats startet keine Implementierung außerhalb des erteilten Auftrags.

## EP-06 · Auftragsaufnahme am 15.11.2026

- Agentarium Rulebook und Process 1.4 aus `9962810b895baf10f8d71dd9a1f7387cca049b77` geladen. Archivmodus `big-quest` / `BQ-EVAL-01`. [Auftragsanstoß](https://github.com/pahlborn/agentarium/issues/2#issuecomment-6889047223). Issue #2 bis Kommentar `6879503934` (14.11., 15:14:19 UTC) abgeglichen. Die historische Cadence-Abschlusszählung bleibt unbekannt.
- Autorisiert: US-601–603 lokal; #194 / US-202 sowie produktiver Claude-Betrieb bleiben offene Abhängigkeiten. Big-Quest-main `7995d6968e3895b88f8ed2c3b0476683e5720c1a` und ZIP 05 geprüft. Der direkte lokale Git-Clone verlangt authentifizierten Zugriff. Atlas stellt den Quellbaum über die lesbare GitHub-Schnittstelle aus unveränderlichen Git-Objekten wieder her und prüft ihn vor Änderungen gegen `7493d82b02769d7d0511c66b01f7fe1abc257f67`.
- Forge: In dieser Sitzung ist kein direkter Claude-Kanal verfügbar. Der vorhandene Workflow am geprüften Stand ist ein Identitätsprobe-Workflow und liegt außerhalb der Freigabe. Nächster Schritt: Wiederherstellung abschließen, dann separate Entwicklungsvertretung, Argus und Sentinel im freigegebenen Rahmen einsetzen.

### Wiederherstellung verifiziert

- Alle 334 eindeutigen Git-Blobs der Quellbasis per SHA geprüft. Ausgangsbaum `ffdc932e6b7f2b4195f7b119d4ba445409512180`. `git am` hat alle sechs Patches aus Stand 05 angewendet. Lokaler Commit `0e999dad04f6bed4d76c9d5d978cc994d0cf1009`, exakt erwarteter Baum `7493d82b02769d7d0511c66b01f7fe1abc257f67`. Der neue Commit-Hash entsteht aus der lokalen Rekonstruktion. Arbeitsbaum sauber.
- Nächster Schritt: bestehende Bestätigung, Rechteprüfung und Ereignisspeicherung technisch verbinden. Codex-Entwicklungsvertretung übernimmt den Quellbaum. Argus prüft Sicherheit; Sentinel prüft die Abnahme am fertiggestellten Stand.

### Technischer Abgleich und Prüfstart

- Codex-Entwicklungsvertretung `/root/springer_ep06` untersucht und bearbeitet den bestehenden Schreibpfad. Der geplante geschützte Ablauf verwendet vorhandene versiegelte Ereignisbündel und eine atomare Git-Ref-Aktualisierung für Bündel und Vorgangszuordnung. Bestehende Konto-/Familienablage ist ein separater Pfad. [Technischer Checkpoint](https://github.com/pahlborn/agentarium/issues/2#issuecomment-6889101520).
- `/root/argus_ep06` hat Rechteabgrenzung, Legacy-Schreibumgehung, dauerhaft atomare Wiederholung und Revisionskonflikte am Baum `7493d82b` vorgeprüft. `/root/sentinel_ep06` hat die unabhängigen Abnahmefälle festgelegt. Die Prüfung des Implementierungsstands folgt. [Argus](https://github.com/pahlborn/agentarium/issues/2#issuecomment-6889101200) · [Sentinel](https://github.com/pahlborn/agentarium/issues/2#issuecomment-6889101333).
- Basis `0e999dad` / `7493d82b`: `npm run test:module` mit 383/383 bestanden. Vorinstalliertes Chromium 156 scheitert an Unix-Domain-Socket `EPERM`. Lokal bereitgestelltes Headless-Chromium startet erfolgreich über `browserStarten`; erneute gezielte Basissuite gestartet. Nächster Schritt: Implementierungsstand abnehmen. [#194](https://github.com/pahlborn/bis-school-app_src/pull/194) ist weiterhin offen.

### Basisregression und Kompatibilitätsentscheidung

- Basis-Commit `0e999dad04f6bed4d76c9d5d978cc994d0cf1009`, Baum `7493d82b02769d7d0511c66b01f7fe1abc257f67`: 383 Modulchecks und 23 gezielte Dienst-/Browser-/Testinstanzprüfungen bestanden. Im Browser liefen vorhandener EP-04-Formularweg sowie Bearbeitung und Rücknahme. Chromium Headless Shell läuft über den bestehenden Playwright-Startweg.
- Für den lokalen Adapter festgelegt: neue, zweckgebundene verschlüsselte Bewertungsbündel im Schulbereich, vorhandene v1-Bündel weiter lesbar. Dadurch kann die Leseseite Mitglieds-, Geräte- und Schlüsselereignisse aus dem eingeschränkten EP-06-Schreibpfad abweisen. Zielgeräte brauchen vor einer späteren Freigabe einen kompatiblen Leser. Der Bewertungsdienst erhält dabei keinen Bewertungsklartext. Nächster Nachweis: Originalformular → geschützter Adapter → zweites autorisiertes Browserprofil und Revocation-Gegenprobe.

### Implementierungscheckpoint · lokaler Commit e077bdeb

- Codex-Entwicklungsvertretung: `e077bdeb306c2fb3bba130ece3924d3b865b316b`, Baum `a27366f25e31beea49e1a27396b2dcf651ec554b`. Geschützter Git-Speicher, Rechteprüfung, verschlüsselte Vormerkung und neuer Abgleichstatus sind im bestehenden Formular verdrahtet. Argus prüft exakt diesen Stand. Sentinel startet einen unabhängigen Gegenversuch. Die Vollständigkeit der Story-Abnahme wird am Kandidaten nach den gezielten Tests entschieden.
- Nächster Schritt: Originalformular im lokalen Zwei-Browser-Test gegen den Git-Nachbau prüfen sowie Antwortverlust, Korrekturen und Rechteentzug nachweisen.

### Zwischenprüfung am Commit e077bdeb

- Sentinel hat alte v1- und neue v2-Bündel gemeinsam gelesen und vier manipulierte Varianten sowie Wiederholung geprüft. Die unabhängig reproduzierte Testumgebung nutzt Chromium Headless Shell 153.
- Argus meldet am Zwischenstand die kindübergreifende Offline-Nachholung, Bereichsschlüsselrotation bei einem bereits versiegelten Request, Kriterienbelege beim Duplikatvergleich und lokale Kindlöschung als Korrekturbedarf. Der alte Konto-/Familienspeicher im Testaufbau hat weiterhin einen separaten Browser-Token. Der neue Bewertungsendpunkt vergibt keinen GitHub-Schreibtoken.
- In der Atlas-Regressionssuite am Zwischencommit erwartete der bestehende EP-04-Browsertest eine Bestätigung ohne konfigurierten Bewertungsadapter (21/22 grün). Nächster Schritt: Fixture an den neuen Bestätigungspfad anbinden und die Korrekturen am neuen Commit prüfen.

### Zwei autorisierte Browserprofile lokal geprüft

- Entwicklungskandidat `508f7c7c15455993f1f4b7ac348f91fcb2146f4a`, Baum `990f43f1da39f9124971f17f7cfff47af69cf7ff`. Der vorhandene Elternformulartest mit simuliertem Claude bestätigt offline, zeigt den ausstehenden Status, verliert die Serverantwort nach erfolgreichem Schreiben und holt den identischen Vorgang nach. Das zweite separat autorisierte Elternprofil liest dasselbe Ereignis genau einmal über den Dienst. Der Test sperrt dort direkten GitHub-Zugriff und entfernt den alten Testzugang aus dem Browser.
- Der lokale Server-/Git-Nachbau prüft parallele gleichwertige Bestätigung, Git-Ref-Konflikt, Antwortverlust, stabile Vorgangsbelege nach Schlüsselwechsel, Abweisen eines neuen alten Schlüsselstands sowie verweigerte Lese-/Schreibzugriffe nach Geräteentzug. Argus und Sentinel prüfen den Kandidaten unabhängig. Nächster Schritt: Abschlussbefunde einarbeiten, Modulregression und Wiederherstellung nachweisen.

### Wiederaufnahme nach Rücksetzung des Cloud-Arbeitsbereichs

- Vor der Rücksetzung war EP-06 lokal an `53186afc2fdeec9187b9cc610ad1420551ed3379` / Baum `bada8db1678f0d5be605349fa770a03c70732908` umgesetzt. Argus hatte den fokussierten lokalen Diensttest an diesem Commit ausgeführt. Sentinel hatte Offline-Wiederholung und das zweite Browserprofil an `508f7c7c` unabhängig geprüft. Die vollständige Schlussregression und die Paketübergabe waren zu diesem Zeitpunkt offen.
- Der frühere EP-06-Quellbaum ist im neu gestarteten Arbeitsbereich nicht vorhanden. Wiederherstellbare Basis ist der überprüfte **Originalcommit** `9fbd987d4d3f02b1ac890bc0fe508f0bfa73a3e0`, Baum `7493d82b02769d7d0511c66b01f7fe1abc257f67`. Die alte Prüfevidenz bleibt auf ihren jeweiligen Stand begrenzt.
- Atlas lässt die Änderungen aus den konkreten technischen Prüfbefunden wiederaufbauen und prüft den daraus resultierenden Commit neu. Nächster Schritt ist die integrierte Zwischenablage im wiederherstellbaren Paket. [Wiederaufnahme im Archiv](https://github.com/pahlborn/agentarium/issues/2#issuecomment-6889435563)

### Server-Wiederherstellung als Patch gesichert

- Wiederherstellungscheckpoint `d23591df2d256cdecb4d1e2b870348c147eaab57`, Baum `f793f99476406c222c6d40f91380c8ac47d4bba1`. Der geschützte Dienstpfad ist wieder vorhanden. Die Entwicklungsvertretung meldet zehn grüne bestehende Diensttests. Kumulativer und inkrementeller Patch ergeben diesen Baum. [Entwicklungsstand 06, Zwischenversion](https://chatgpt.com/library?file_id=libfile_94c88248490c8191a17d7932a1648978&account_id=personal)
- Nächster Schritt ist die Integration der ebenfalls rekonstruierten Browseränderungen mit Formular, Offline-Warteschlange und gezielten EP-06-Nachweisen. Die Zwischenversion enthält bis dahin den Serverteil.

### Wiederhergestellte Integration gesichert

- Commit `7ce56ab5f4e4fd186faf1627171cf614889b6f5b`, Baum `813039eb74f647205857b2e5c718827a2928e1c2`. Geschützter Dienst, v1/v2-Leser, bestehendes Formular, bestätigungsgebundener Schreibpfad und verschlüsselte Offline-Warteschlange sind integriert. Gezielte Modul- und Build-Gegenproben grün. [Wiederherstellbares integriertes Zwischenpaket](https://chatgpt.com/library?file_id=libfile_94c88248490c8191a17d7932a1648978&account_id=personal)
- Argus hat den Wiederaufbau des Diensts am Servercheckpoint zusätzlich mit einem unabhängigen synthetischen HTTP- und Signaturnachweis geprüft. Der integrierte Stand ist Gegenstand der laufenden neuen Regression und unabhängigen Abnahme. Nächstes Ergebnis sind die neuen GitHub-Nachbau- und Browser-Nachweise am wiederhergestellten Code.
