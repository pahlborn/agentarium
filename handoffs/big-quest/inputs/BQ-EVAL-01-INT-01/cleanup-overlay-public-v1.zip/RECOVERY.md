# Local cleanup overlay v1
Base commit: 7995d6968e3895b88f8ed2c3b0476683e5720c1a
This archive is an overlay, not a full repository or Git history.
On the exact base, restore payload files at their repository-relative paths, delete only the two paths marked deleted in manifest.json, and verify SHA-256 of every restored file against the manifest.
The deleted original records are intentionally absent from this archive. No Git metadata, original-file deletion diff, local credentials, node_modules, dist, databases or old personal-data backup is included.
This local artifact is NOT approved for remote publication. Broader historical cleanup and EP06 integration remain separate.
