# Public task input variant v1

Source archive SHA-256: f961223ef35a16ab059f7ad63303b394fa323030d574acda4887fa062115dcf7
This is a publication copy, not the byte-identical original handover/review artifact.
Only original account identifiers remaining in test fixtures and token-shaped test literals were replaced with explicit deterministic dummy values. No original identifier mapping or credential values are included. The application tests were NOT run for these publication edits. Earlier reviews/logs remain evidence for their original exact versions, not this variant.
The cumulative and incremental patches, where present, are preserved byte-for-byte. Use their documented original Git bases for later reconstruction; do not substitute the incomplete anonymized source snapshot. Historical source tree/hash claims in supplied documents describe the original artifacts.
Changed payload members and occurrence counts (no original values):

```json
{
  "payload/tests/familienfassung.test.mjs": {
    "original_account_identifier_occurrences_replaced": 2,
    "token_shaped_test_values_replaced": 1
  },
  "payload/tests/testinstanz.test.mjs": {
    "original_account_identifier_occurrences_replaced": 1,
    "token_shaped_test_values_replaced": 1
  }
}
```
